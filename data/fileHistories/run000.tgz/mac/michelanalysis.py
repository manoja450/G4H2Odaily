import os
import uproot
import numpy as np
import matplotlib.pyplot as plt

# ============================================================
# Base project directory and subfolders
# ============================================================
base_dir = "/home/manoja450/G4WithoutLeadSheilding/MODULE2/CUSTOMOPTICALMODULE2/NEXTmodify/G4d2o_DATA_DRIVEN_COPY"
data_dir = os.path.join(base_dir, "data")
mac_dir = os.path.join(base_dir, "mac")

michel_path = os.path.join(mac_dir, "all_histograms.root")
sim_path = os.path.join(data_dir, "Sim_D2ODetector001.root")

# ============================================================
# Output folder for plots (created in the current working directory)
# ============================================================
plots_dir = os.path.join(os.getcwd(), "PLOTS")
os.makedirs(plots_dir, exist_ok=True)

# ============================================================
# ROOT-like plotting style
# ============================================================
plt.rcParams.update({
    "font.family": "DejaVu Serif",
    "font.size": 18,
    "axes.linewidth": 1.4,
})

# ============================================================
# Threshold (same for Data and Monte Carlo)
# ============================================================
cut_value = 60.0  # PE

# ============================================================
# Read Michel (Real Data) histogram
# ============================================================
michel_file = uproot.open(michel_path)
h_michel = michel_file["michel_energy"]

edges = h_michel.axis().edges()
counts = h_michel.values()

# Histogram bin centers
centers = (edges[:-1] + edges[1:]) / 2

# Keep only bins above threshold
first_bin = np.where(centers >= cut_value)[0][0]

michel_edges = edges[first_bin:]
michel_counts = counts[first_bin:]

# Normalize
michel_norm = michel_counts / michel_counts.sum()

# ============================================================
# Read Geant4 Monte Carlo
# ============================================================
sim_file = uproot.open(sim_path)
tree = sim_file["Sim_Tree"]

num_hits = tree["eventData/numHits"].array().to_numpy()

# Apply threshold
num_hits = num_hits[num_hits >= cut_value]

# Histogram using same binning as Michel data
sim_counts, _ = np.histogram(num_hits, bins=michel_edges)

# Normalize
sim_norm = sim_counts / sim_counts.sum()

# ============================================================
# Bin width (for y-axis label)
# ============================================================
bin_width = michel_edges[1] - michel_edges[0]

# ============================================================
# Plot
# ============================================================
fig, ax = plt.subplots(figsize=(12, 8))

# Geant4 Monte Carlo
ax.stairs(
    sim_norm,
    michel_edges,
    color="red",
    linewidth=1.5,
    label="G4 Monte Carlo"
)

# Real Data
ax.stairs(
    michel_norm,
    michel_edges,
    color="blue",
    linewidth=1.5,
    label="Real Data"
)

# ============================================================
# Axes
# ============================================================
ax.set_xlim(0, 800)
ax.set_ylim(bottom=0)

ax.set_xlabel("Number of Photoelectrons (PE)", fontsize=22)
ax.set_ylabel(f"Normalized Counts / {bin_width:g} PE", fontsize=22)

ax.set_title("Michel Electron Spectrum", fontsize=26, pad=15)

# ROOT-like ticks
ax.minorticks_on()

ax.tick_params(
    axis="both",
    which="major",
    direction="in",
    length=8,
    width=1.4,
    labelsize=18,
    top=True,
    right=True
)

ax.tick_params(
    axis="both",
    which="minor",
    direction="in",
    length=4,
    width=1.0,
    top=True,
    right=True
)

# Remove grid
ax.grid(False)

# Legend
ax.legend(
    loc="upper right",
    fontsize=18,
    frameon=True,
    framealpha=1,
    edgecolor="black",
    fancybox=False
)

plt.tight_layout()

# Save figure into PLOTS/
pdf_out = os.path.join(plots_dir, "MichelSpectrumComparison.pdf")
png_out = os.path.join(plots_dir, "MichelSpectrumComparison.png")

plt.savefig(pdf_out, dpi=300, bbox_inches="tight")
plt.savefig(png_out, dpi=300, bbox_inches="tight")
print(f"Saved plot to: {pdf_out}")
print(f"Saved plot to: {png_out}")

plt.show()

# ============================================================
# Statistics
# ============================================================
michel_centers = (michel_edges[:-1] + michel_edges[1:]) / 2
michel_mean = np.average(michel_centers, weights=michel_counts)

print("=" * 60)
print(f"Threshold              : {cut_value:.0f} PE")
print(f"Real Data Events       : {michel_counts.sum():.0f}")
print(f"G4 Monte Carlo Events  : {len(num_hits)}")
print(f"Real Data Mean PE      : {michel_mean:.2f}")
print(f"G4 Monte Carlo Mean PE : {num_hits.mean():.2f}")
print(f"G4 Monte Carlo Median  : {np.median(num_hits):.2f}")
print("=" * 60)
